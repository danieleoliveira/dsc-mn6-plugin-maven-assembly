The project is ready for distribution.


distribution > database > 'DIMP.sql'
- Run the 'DIMP.sql' file to set the database.

distribution > 'run.bat'
- Run the 'run.bat' file to execute application.

distribution > manuals >
- 'Product Manual v01.doc'
- 'User Manual v01.doc'

distribution > lib > '*.war'
- Project compliled.

distribution > project > '1.0-dsc-mn6-plugin-maven-assembly'
- Project non-compiled.